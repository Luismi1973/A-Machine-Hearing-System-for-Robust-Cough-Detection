import os
import numpy as np
import librosa
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# Directorio con los audios
audio_dir = 'toses300ms/'

def calc_avg_sd(features):
    mean = np.mean(features, axis=1)
    std_dev = np.std(features, axis=1)
    return mean, std_dev

# extraer caracter�sticas a corto plazo (short-term features)
def extract_short_term_features(audio, sr, frame_size=0.03, hop_size=0.01):
    frame_length = int(frame_size * sr)
    hop_length = int(hop_size * sr)
    
    # Extraer MFCCs como caracter�sticas a corto plazo
    mfcc = librosa.feature.mfcc(audio, sr=sr, n_mfcc=13, n_fft=frame_length, hop_length=hop_length)
    return mfcc.T  # OJO: cada frame es una fila

# Generar codebook mediante clustering K-means
def generate_codebook(all_features, num_words):
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(all_features)
    
    kmeans = KMeans(n_clusters=num_words, random_state=0)
    kmeans.fit(scaled_features)
    codebook = kmeans.cluster_centers_
    return codebook, kmeans

def vector_quantization(features, codebook):
    distances = np.linalg.norm(features[:, np.newaxis] - codebook, axis=2)
    closest_words = np.argmin(distances, axis=1)
    return closest_words

# Creamos histograma de audio_words
def generate_histogram(audio_words, num_words):
    hist, _ = np.histogram(audio_words, bins=np.arange(0, num_words + 1))
    return hist

# Procesar archivos de audio
audio_files = [f for f in os.listdir(audio_dir) if f.endswith('.wav')]
num_audio_words = 50

# Almacenar todas las caracter�sticas a corto plazo para generar el codebook
all_features = []

# Primera pasada: extraer caracter�sticas a corto plazoo
for file in audio_files:
    file_path = os.path.join(audio_dir, file)
    
    audio, sr = librosa.load(file_path, sr=None)
    features = extract_short_term_features(audio, sr)
    all_features.append(features)

all_features = np.vstack(all_features)
codebook, kmeans_model = generate_codebook(all_features, num_audio_words)

# Segunda pasada: calcular media, desviaci�n est�ndar y generar BoAW para cada archivo
for file in audio_files:
    file_path = os.path.join(audio_dir, file)
    
    audio, sr = librosa.load(file_path, sr=None)
    features = extract_short_term_features(audio, sr)
    mean, std_dev = calc_avg_sd(features)
    print(f"Archivo: {file}")
    print(f"Media: {mean}")
    print(f"Desviaci�n est�ndar: {std_dev}")
    
    audio_words = vector_quantization(features, codebook)
    histogram = generate_histogram(audio_words, num_audio_words)
    
    print(f"Histograma de Audio Words para {file}:")
    print(histogram)
    
    # Histograma de las audio_words:
    plt.figure()
    plt.bar(range(num_audio_words), histogram)
    plt.title(f"Histograma de Audio Words para {file}")
    plt.xlabel("Audio Word")
    plt.ylabel("Frecuencia")
    plt.show()

     