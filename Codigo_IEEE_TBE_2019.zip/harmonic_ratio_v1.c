#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <fftw3.h>

#define SAMPLE_RATE 44100
#define FRAME_SIZE 1024
#define HARMONIC_THRESHOLD 100  

// Funci�n para calcular el H.R.
float harmonic_ratio(float *signal, int size) {
    // Inicializar FFTW
    fftwf_complex *in = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * size);
    fftwf_complex *out = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * size);
    fftwf_plan p = fftwf_plan_dft_1d(size, in, out, FFTW_FORWARD, FFTW_ESTIMATE);

    for (int i = 0; i < size; i++) {
        in[i][0] = signal[i]; // Parte real
        in[i][1] = 0.0;       // Parte imaginaria
    }
    fftwf_execute(p);
    float harmonic_energy = 0.0;
    float non_harmonic_energy = 0.0;
    float fundamental_freq = -1;
    
    float max_magnitude = 0.0;
    int fundamental_index = 0;
    for (int i = 0; i < size / 2; i++) {
        float magnitude = sqrt(out[i][0] * out[i][0] + out[i][1] * out[i][1]);
        if (magnitude > max_magnitude) {
            max_magnitude = magnitude;
            fundamental_index = i;
        }
    }
    
    fundamental_freq = (float)fundamental_index * SAMPLE_RATE / size;
    
    for (int i = 0; i < size / 2; i++) {
        float magnitude = sqrt(out[i][0] * out[i][0] + out[i][1] * out[i][1]);
        if (i == fundamental_index || 
            (i % fundamental_index == 0 && i / fundamental_index < HARMONIC_THRESHOLD)) {
            harmonic_energy += magnitude;
        } else {
            non_harmonic_energy += magnitude;
        }
    }

    // Liberar recursos
    fftwf_destroy_plan(p);
    fftwf_free(in);
    fftwf_free(out);

    // Calcular el H.R.
    return harmonic_energy / (non_harmonic_energy + 1e-10); // A�adir un peque�o epsilon para evitar divisi�n por cero
}
