// Calculamos ASF
float audio_spectrum_flatness(float *spectrum, int size) {
    float geometric_mean = 1.0;
    float arithmetic_mean = 0.0;

    // Calcular la media aritm�tica
    for (int i = 0; i < size / 2; i++) {
        float magnitude = spectrum[i];
        arithmetic_mean += magnitude;
        geometric_mean *= magnitude;
    }
    arithmetic_mean /= (size / 2);

    // Calcular la media geom�trica
    geometric_mean = pow(geometric_mean, 1.0 / (size / 2));

    // Calcular la planitud del espectro
    return geometric_mean / (arithmetic_mean + 1e-10); // A�adir epsilon para evitar divisi�n por cero
}
