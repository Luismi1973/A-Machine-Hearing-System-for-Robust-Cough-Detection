    % Procesar cada frame
    for j = 1:size(frames, 2)
        frame = frames(:, j);
        
        % Calcular el espectrograma para cada una de las bandas de frecuencia
        for k = 1:size(bandas_frecuencia, 1)
            % Filtro de banda de frecuencia
            [b, a] = butter(4, bandas_frecuencia(k, :) / (fs_reducida / 2));
            frame_filtrado = filter(b, a, frame);
            
            % Calcular el espectro del frame filtrado
            [S, f] = periodogram(frame_filtrado, [], [], fs_reducida);
            
            % Extraccion des características espectrales
            spectral_centroid = sum(f .* S) / sum(S);
            spectral_bandwidth = sqrt(sum(((f - spectral_centroid) .^ 2) .* S) / sum(S));
            spectral_crest_factor = max(S) / mean(S);
            spectral_flatness = geomean(S) / mean(S);
            spectral_flux = sum((diff(S)).^2);
            spectral_rolloff = f(find(cumsum(S) >= 0.85*sum(S), 1));  % Rolloff al 85%
            
            % Otros parámetros espectrales
            f50 = find(cumsum(S) >= 0.5 * sum(S), 1);
            f90 = find(cumsum(S) >= 0.9 * sum(S), 1);
            ratio_f50_f90 = f(f50) / f(f90);
            
            % Cálculo de la entropía espectral (Shannon y Renyi)
            spectral_entropy = -sum(S .* log(S));
            renyi_entropy = sum(S.^2);
            
            % Cálculo pico de entropía 
            peak_entropy = sum(max(S) .* log(max(S)) / sum(S));
            
            % Kurtosis y Skewness
            spectral_kurtosis = kurtosis(S);
            spectral_skewness = skewness(S);
            
            % Potencia relativa
            relative_power = bandpower(S, f, bandas_frecuencia(k, :));
            
            % características para cada frame y banda
            fprintf('Frame %d, Banda %d\n', j, k);
            fprintf('Centroid: %f, Bandwidth: %f, Crest: %f, Flatness: %f\n', ...
                spectral_centroid, spectral_bandwidth, spectral_crest_factor, spectral_flatness);
            fprintf('Flux: %f, Roll-off: %f, F50/F90: %f, Entropy: %f\n', ...
                spectral_flux, spectral_rolloff, ratio_f50_f90, spectral_entropy);
            fprintf('Renyi Entropy: %f, Peak Entropy: %f, Kurtosis: %f, Skewness: %f, Relative Power: %f\n\n', ...
                renyi_entropy, peak_entropy, spectral_kurtosis, spectral_skewness, relative_power);
        end
    end
end
