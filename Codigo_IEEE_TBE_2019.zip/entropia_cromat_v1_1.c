#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <fftw3.h>

#define SAMPLE_RATE 44100
#define NUM_BANDS 12

//  Entrop�a Crom�tica
float chromatic_entropy(float *spectrum, int size) {
    fftwf_complex *in = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * size);
    fftwf_complex *out = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * size);
    fftwf_plan p = fftwf_plan_dft_1d(size, in, out, FFTW_FORWARD, FFTW_ESTIMATE);

    for (int i = 0; i < size; i++) {
        in[i][0] = spectrum[i]; // Parte real
        in[i][1] = 0.0;        // Parte imaginaria
    }

    // Ejecutar FFT
    fftwf_execute(p);

    float band_energy[NUM_BANDS] = {0.0};
    float band_width = SAMPLE_RATE / size;
    float band_limit = 0.0;

    for (int i = 0; i < size / 2; i++) {
        float magnitude = sqrt(out[i][0] * out[i][0] + out[i][1] * out[i][1]);
        band_limit = (i + 1) * band_width;
        int band_index = (int)(band_limit / (SAMPLE_RATE / NUM_BANDS));
        if (band_index < NUM_BANDS) {
            band_energy[band_index] += magnitude;
        }
    }

    // Calcular la entrop�a crom�tica
    float total_energy = 0.0;
    for (int i = 0; i < NUM_BANDS; i++) {
        total_energy += band_energy[i];
    }

    float entropy = 0.0;
    for (int i = 0; i < NUM_BANDS; i++) {
        if (band_energy[i] > 0) {
            float prob = band_energy[i] / (total_energy + 1e-10); // A�adir epsilon para evitar divisi�n por cero
            entropy -= prob * log(prob);
        }
    }

    fftwf_destroy_plan(p);
    fftwf_free(in);
    fftwf_free(out);

    return entropy;
}

