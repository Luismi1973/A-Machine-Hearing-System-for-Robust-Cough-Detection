% Algoritmo Relieff

labels = randi([0, 1], 50, 1);
[num_muestras, num_features] = size(features);
num_neighbors = 10; % N�mero de vecinos para la b�squeda (puedes ajustar este valor)

feature_weights = relieff(features, labels, num_neighbors);
[sorted_weights, sorted_indices] = sort(feature_weights, 'descend');
num_selected_features = 29;
selected_indices = sorted_indices(1:num_selected_features);
selected_features = features(:, selected_indices);
