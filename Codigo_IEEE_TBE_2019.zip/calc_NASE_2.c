// envolvente normalizada del espectro de audio
float normalized_audio_spectrum_envelope(float *spectrum, int size) {
    float band_min_freq = 62.5;
    float band_max_freq = 4000;
    float band_energy = 0.0;
    float total_energy = 0.0;
    float band_width = SAMPLE_RATE / size;

    // Calcular la energ�a en la banda especificada y la energ�a total
    for (int i = 0; i < size / 2; i++) {
        float freq = i * band_width;
        float magnitude = spectrum[i];
        total_energy += magnitude;

        if (freq >= band_min_freq && freq <= band_max_freq) {
            band_energy += magnitude;
        }
    }

    // Calcular la envolvente normalizada
    return band_energy / (total_energy + 1e-10);
}
