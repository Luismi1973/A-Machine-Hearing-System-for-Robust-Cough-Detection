load features

% N�mero de caracter�sticas
num_features = size(features, 2);

% extraccion del 10% de las caracter�sticas aleatoriamente
porcentaje = 0.10;
num_selected_features = round(num_features * porcentaje);

selected_indices = randperm(num_features, num_selected_features);
selected_features = features(:, selected_indices);

disp('�ndices seleccionados:');
disp(selected_indices);
disp('Caracter�sticas seleccionadas:');
disp(selected_features);
