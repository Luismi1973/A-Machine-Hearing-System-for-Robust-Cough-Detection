% Directorio con los archivos de audio
audio_dir = 'fuentes_audio/';
audio_files = dir(fullfile(audio_dir, '*.wav'));

% Frecuencia de muestreo original y la nueva (reducida)
fs_original = 44100;
fs_reducida = 11025;

% Duración del frame en segundos y solapamiento en milisegundos
frame_duracion = 0.075;  % 75 ms
frame_solapamiento = 0.019;  % 19 ms

% Definicion las bandas de frecuencia
bandas_frecuencia = [0, 500; 500, 1000; 1000, 1500; 1500, 2000; 2000, fs_reducida / 2];

% Recorrer todos los archivos de audio
for i = 1:length(audio_files)
    % Cargar el archivo de audio
    [audio, fs] = audioread(fullfile(audio_dir, audio_files(i).name));
    
    % Resamplear el audio a 11025 Hz
    audio_resampled = resample(audio, fs_reducida, fs);
    
    % Definir el tamaño del frame y el solapamiento en muestras
    frame_size = round(frame_duracion * fs_reducida);
    frame_overlap = round(frame_solapamiento * fs_reducida);
    
    % Dividir el audio en frames
    frames = buffer(audio_resampled, frame_size, frame_overlap, 'nodelay');
