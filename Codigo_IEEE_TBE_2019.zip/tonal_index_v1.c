#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <fftw3.h>

#define SAMPLE_RATE 44100

// Funci�n para calcular el �ndice Tonal
float tonal_index(float *spectrum, int size) {
    // Configuraci�n para FFT
    fftwf_complex *in = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * size);
    fftwf_complex *out = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * size);
    fftwf_plan p = fftwf_plan_dft_1d(size, in, out, FFTW_FORWARD, FFTW_ESTIMATE);

    for (int i = 0; i < size; i++) {
        in[i][0] = spectrum[i]; // Parte real
        in[i][1] = 0.0;        // Parte imaginaria
    }
    fftwf_execute(p);

    float max_magnitude = 0.0;
    int fundamental_index = 0;
    for (int i = 0; i < size / 2; i++) {
        float magnitude = sqrt(out[i][0] * out[i][0] + out[i][1] * out[i][1]);
        if (magnitude > max_magnitude) {
            max_magnitude = magnitude;
            fundamental_index = i;
        }
    }

    float tonal_energy = 0.0;
    float total_energy = 0.0;
    float fundamental_freq = (float)fundamental_index * SAMPLE_RATE / size;

    int harmonic_range = size / 10;
    for (int i = 0; i < size / 2; i++) {
        float magnitude = sqrt(out[i][0] * out[i][0] + out[i][1] * out[i][1]);
        if (i >= fundamental_index - harmonic_range && i <= fundamental_index + harmonic_range) {
            tonal_energy += magnitude;
        }
        total_energy += magnitude;
    }

    fftwf_destroy_plan(p);
    fftwf_free(in);
    fftwf_free(out);

    // Calcular el �ndice Tonal
    return tonal_energy / (total_energy + 1e-10); // A�adir epsilon para evitar divisi�n por cero
}

