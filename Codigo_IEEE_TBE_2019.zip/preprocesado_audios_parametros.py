import os
import librosa
import numpy as np
import scipy.signal as signal
import matplotlib.pyplot as plt

# Funciones para c�lculo de caracter�sticas espectrales
def spectral_centroid(S, sr):
    return np.sum(np.arange(len(S)) * S) / np.sum(S)

def spectral_bandwidth(S, sr, centroid):
    return np.sqrt(np.sum(((np.arange(len(S)) - centroid) ** 2) * S) / np.sum(S))

def spectral_crest_factor(S):
    return np.max(S) / np.mean(S)

def spectral_flatness(S):
    return scipy.stats.gmean(S) / np.mean(S)

def spectral_flux(S, S_prev):
    return np.sum((S - S_prev) ** 2)

def spectral_rolloff(S, sr, roll_percent=0.85):
    cumulative_sum = np.cumsum(S)
    threshold = roll_percent * np.sum(S)
    return np.where(cumulative_sum >= threshold)[0][0]

def relative_power(S, f, band):
    band_power = np.trapz(S[(f >= band[0]) & (f <= band[1])])
    total_power = np.trapz(S)
    return band_power / total_power

# Directorio e audio
audio_dir = 'fuentes_audio/'
audio_files = [f for f in os.listdir(audio_dir) if f.endswith('.wav')]

fs_original = 44100
fs_reducida = 11025
frame_duracion = 0.075  # 75 ms
frame_solapamiento = 0.019  # 19 ms

# bandas de frecuencia
bandas_frecuencia = [(0, 500), (500, 1000), (1000, 1500), (1500, 2000), (2000, fs_reducida // 2)]

# Procesado de audios
for archivo in audio_files:
    audio, sr = librosa.load(os.path.join(audio_dir, archivo), sr=fs_original)
    audio_resampled = librosa.resample(audio, orig_sr=fs_original, target_sr=fs_reducida)
    
    # N�mero de muestras por frame y por solapamiento
    frame_size = int(frame_duracion * fs_reducida)
    frame_overlap = int(frame_solapamiento * fs_reducida)
    
    # Segmentaci�n en frames
    frames = librosa.util.frame(audio_resampled, frame_length=frame_size, hop_length=frame_size - frame_overlap).T
    
    # Procesado frames:  
    for j, frame in enumerate(frames):
        S_prev = np.zeros_like(frame)
        
        for banda in bandas_frecuencia:
            b, a = signal.butter(4, [banda[0] / (fs_reducida / 2), banda[1] / (fs_reducida / 2)], btype='band')
            frame_filtrado = signal.lfilter(b, a, frame)
            
            f, S = signal.periodogram(frame_filtrado, fs_reducida)
            
            centroid = spectral_centroid(S, fs_reducida)
            bandwidth = spectral_bandwidth(S, fs_reducida, centroid)
            crest_factor = spectral_crest_factor(S)
            flatness = spectral_flatness(S)
            flux = spectral_flux(S, S_prev)
            rolloff = spectral_rolloff(S, fs_reducida)
            relative_power_val = relative_power(S, f, banda)
            
            print(f'Frame {j + 1}, Banda {banda[0]}-{banda[1]} Hz')
            print(f'Centroid: {centroid:.4f}, Bandwidth: {bandwidth:.4f}')
            print(f'Crest Factor: {crest_factor:.4f}, Flatness: {flatness:.4f}')
            print(f'Flux: {flux:.4f}, Roll-off: {rolloff:.4f}')
            print(f'Relative Power: {relative_power_val:.4f}')
            print()
            
            S_prev = S
