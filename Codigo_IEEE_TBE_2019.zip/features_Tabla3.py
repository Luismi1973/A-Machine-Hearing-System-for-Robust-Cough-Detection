import os
import librosa
import numpy as np
import scipy.signal as signal
from scipy.fftpack import dct

# Directorio de audio frames
audio_dir = 'audio_frames/'

# Par�metros de audio
fs = 44100  # Frecuencia de muestreo

# Filtrar la banda de frecuencias 62.5 - 4000 Hz
def filter_band(audio, sr, lowcut, highcut):
    nyquist = sr / 2.0
    b, a = signal.butter(4, [lowcut / nyquist, highcut / nyquist], btype='band')
    return signal.lfilter(b, a, audio)

def harmonic_ratio(audio, sr):
    harmonic, percussive = librosa.effects.hpss(audio)
    return np.sum(harmonic**2) / (np.sum(audio**2) + 1e-7)

# Calc.Root MFCC 
def root_mfcc(audio, sr, n_mfcc=13, n_fft=2048, hop_length=512):
    mfccs = librosa.feature.mfcc(audio, sr=sr, n_mfcc=n_mfcc+1, n_mels=30, fmax=4000)
    root_mfccs = np.sign(mfccs[1:]) * np.abs(mfccs[1:]) ** 0.5
    dct_mfccs = dct(root_mfccs, axis=0, type=2, norm='ortho')[1:14]  # DCT del 2� al 14�
    return dct_mfccs

# Calc. Audio Spectrum Flatness (ASF) en62.5 - 4000 Hz
def audio_spectrum_flatness(audio, sr, n_fft=2048, hop_length=512):
    filtered_audio = filter_band(audio, sr, 62.5, 4000)
    S = np.abs(librosa.stft(filtered_audio, n_fft=n_fft, hop_length=hop_length))
    flatness = librosa.feature.spectral_flatness(S=S)
    return flatness

# Calcula Normalized Audio Spectrum Envelope (NASE)
def normalized_audio_spectrum_envelope(audio, sr, n_fft=2048, hop_length=512):
    filtered_audio = filter_band(audio, sr, 62.5, 4000)
    S = np.abs(librosa.stft(filtered_audio, n_fft=n_fft, hop_length=hop_length))
    envelope = np.mean(S, axis=1) / np.max(S, axis=1)
    return envelope

# Calc. Tonal Index (TI)
def tonal_index(audio, sr):
    harmonic, _ = librosa.effects.hpss(audio)
    tonal_index_value = np.sum(harmonic**2) / (np.sum(audio**2) + 1e-7)
    return tonal_index_value

# Calcula Chromatic Entropy (ChroEn)
def chromatic_entropy(audio, sr):
    chroma = librosa.feature.chroma_stft(audio, sr=sr, n_chroma=12, n_fft=2048)
    entropy = -np.sum(chroma * np.log(chroma + 1e-7), axis=0)
    return np.mean(entropy)

# Subband Spectral Centroid Histograms (SSCH)
def subband_spectral_centroid_histograms(audio, sr, n_fft=2048, hop_length=512, n_mfcc=13):
    S = np.abs(librosa.stft(audio, n_fft=n_fft, hop_length=hop_length))
    spectral_centroids = librosa.feature.spectral_centroid(S=S, sr=sr)
    histograms, bin_edges = np.histogram(spectral_centroids, bins=38, range=(0, 4000))
    histograms = histograms / np.sum(histograms)  # Normalizaci�n
    dct_histograms = dct(histograms, type=2, norm='ortho')[1:14]  # DCT del 2� al 14�
    return dct_histograms

# Procesar los archivos de audio en el directorio
audio_files = [f for f in os.listdir(audio_dir) if f.endswith('.wav')]

for file in audio_files:
    file_path = os.path.join(audio_dir, file)
    audio, sr = librosa.load(file_path, sr=fs)
    
    frame_size = int(0.075 * sr)
    hop_length = int(0.019 * sr)
    frames = librosa.util.frame(audio, frame_length=frame_size, hop_length=hop_length).T
    
    for i, frame in enumerate(frames):
        print(f"Procesando Frame {i + 1} del archivo {file}")
        
        # Calcular par�metros
        hr = harmonic_ratio(frame, sr)
        rmfcc = root_mfcc(frame, sr)
        asf = audio_spectrum_flatness(frame, sr)
        nase = normalized_audio_spectrum_envelope(frame, sr)
        ti = tonal_index(frame, sr)
        chroen = chromatic_entropy(frame, sr)
        ssch = subband_spectral_centroid_histograms(frame, sr)
        
     