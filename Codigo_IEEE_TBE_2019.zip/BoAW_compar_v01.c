#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define NUM_WORDS 50  // N�mero de clusters (palabras de audio)
#define NUM_FEATURES 2  // Caracter�sticas: centroide espectral y energ�a
#define MAX_FRAMES 1000  // M�ximo n�mero de frames por archivo
#define MAX_AUDIO_FILES 10  // M�ximo n�mero de archivos de audio

typedef struct {
    float features[NUM_FEATURES];
} AudioWord;

typedef struct {
    float features[NUM_FEATURES];
} Frame;

//  distancia euclidea entre dos vectores de caracter�sticas
float calculate_distance(float* a, float* b, int size) {
    float distance = 0.0;
    for (int i = 0; i < size; i++) {
        distance += (a[i] - b[i]) * (a[i] - b[i]);
    }
    return sqrt(distance);
}

//  Inicializar aleatoriamente los centroides
void initialize_codebook(AudioWord* codebook, Frame* all_frames, int total_frames) {
    for (int i = 0; i < NUM_WORDS; i++) {
        int random_index = rand() % total_frames;
        for (int j = 0; j < NUM_FEATURES; j++) {
            codebook[i].features[j] = all_frames[random_index].features[j];
        }
    }
}

// Asignamos cada frame al cluster m�s cercano
void assign_clusters(Frame* frames, int num_frames, AudioWord* codebook, int* assignments) {
    for (int i = 0; i < num_frames; i++) {
        float min_distance = calculate_distance(frames[i].features, codebook[0].features, NUM_FEATURES);
        int closest_cluster = 0;
        for (int j = 1; j < NUM_WORDS; j++) {
            float distance = calculate_distance(frames[i].features, codebook[j].features, NUM_FEATURES);
            if (distance < min_distance) {
                min_distance = distance;
                closest_cluster = j;
            }
        }
        assignments[i] = closest_cluster;
    }
}

// Actualiza los centroides 
void update_codebook(Frame* frames, int num_frames, AudioWord* codebook, int* assignments) {
    float cluster_sum[NUM_WORDS][NUM_FEATURES] = {0};
    int cluster_count[NUM_WORDS] = {0};

    for (int i = 0; i < num_frames; i++) {
        int cluster = assignments[i];
        for (int j = 0; j < NUM_FEATURES; j++) {
            cluster_sum[cluster][j] += frames[i].features[j];
        }
        cluster_count[cluster]++;
    }

    // Actualizar centroides
    for (int i = 0; i < NUM_WORDS; i++) {
        if (cluster_count[i] > 0) {
            for (int j = 0; j < NUM_FEATURES; j++) {
                codebook[i].features[j] = cluster_sum[i][j] / cluster_count[i];
            }
        }
    }
}

// Fistograma 
void generate_histogram(int* assignments, int num_frames, int* histogram) {
    for (int i = 0; i < num_frames; i++) {
        histogram[assignments[i]]++;
    }
}

void print_histogram(int* histogram) {
    printf("Histograma de Audio Words:\n");
    for (int i = 0; i < NUM_WORDS; i++) {
        printf("Audio Word %d: %d\n", i, histogram[i]);
    }
}

int main() {
    Frame all_frames[MAX_FRAMES * MAX_AUDIO_FILES];
    int total_frames = 0;

    // Inicializar el codebook con centroides aleatorios
    AudioWord codebook[NUM_WORDS];
    initialize_codebook(codebook, all_frames, total_frames);

    // Variables para las asignaciones y el histograma
    int assignments[MAX_FRAMES * MAX_AUDIO_FILES];
    int histogram[NUM_WORDS] = {0};

    // Realizar clustering K-means
    for (int iteration = 0; iteration < 10; iteration++) {
        assign_clusters(all_frames, total_frames, codebook, assignments);
        update_codebook(all_frames, total_frames, codebook, assignments);
    }


}

     