#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <fftw3.h>

#define SAMPLE_RATE 44100
#define NUM_FILTERS 30
#define NUM_MFCC 13
#define MEL_MIN_FREQ 0
#define MEL_MAX_FREQ 4000
#define ROOT_VALUE 0.5

// Convertir frecuencia a escala Mel
float freq_to_mel(float freq) {
    return 2595 * log10(1 + freq / 700.0);
}

// Convertir escala Mel a frecuencia
float mel_to_freq(float mel) {
    return 700 * (pow(10, mel / 2595) - 1);
}

// Crear filtros de Mel
void create_mel_filters(float *filters, int num_filters, int size) {
    float mel_min = freq_to_mel(MEL_MIN_FREQ);
    float mel_max = freq_to_mel(MEL_MAX_FREQ);
    float mel_step = (mel_max - mel_min) / (num_filters + 1);

    for (int i = 0; i < num_filters; i++) {
        float mel_center = mel_min + (i + 1) * mel_step;
        float freq_center = mel_to_freq(mel_center);
        int bin_center = (int)(freq_center * size / SAMPLE_RATE);

        for (int j = 0; j < size; j++) {
            float freq = j * SAMPLE_RATE / size;
            float mel_freq = freq_to_mel(freq);
            if (mel_freq < mel_center) {
                filters[i * size + j] = (mel_freq - mel_min) / (mel_center - mel_min);
            } else {
                filters[i * size + j] = (mel_max - mel_freq) / (mel_max - mel_center);
            }
        }
    }
}

// Calcul9o de MFCCs (Ra�z)
void compute_mfcc(float *signal, int size, float *mfccs) {
    // Configuraci�n para FFT
    fftwf_complex *in = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * size);
    fftwf_complex *out = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * size);
    fftwf_plan p = fftwf_plan_dft_1d(size, in, out, FFTW_FORWARD, FFTW_ESTIMATE);

    for (int i = 0; i < size; i++) {
        in[i][0] = signal[i]; // Parte real
        in[i][1] = 0.0;      // Parte imaginaria
    }

    fftwf_execute(p);

    // Crear filtros de Mel
    float *mel_filters = (float*) malloc(NUM_FILTERS * size * sizeof(float));
    create_mel_filters(mel_filters, NUM_FILTERS, size);

    // Aplicar filtros y calcular logaritmo
    float *filtered_spectrum = (float*) malloc(NUM_FILTERS * sizeof(float));
    for (int i = 0; i < NUM_FILTERS; i++) {
        filtered_spectrum[i] = 0.0;
        for (int j = 0; j < size / 2; j++) {
            float magnitude = sqrt(out[j][0] * out[j][0] + out[j][1] * out[j][1]);
            filtered_spectrum[i] += mel_filters[i * size + j] * magnitude;
        }
        filtered_spectrum[i] = log(filtered_spectrum[i] + 1e-10); // A�adir epsilon
    }

    // Calcular DCT para obtener MFCCs
    for (int i = 0; i < NUM_MFCC; i++) {
        mfccs[i] = 0.0;
        for (int j = 0; j < NUM_FILTERS; j++) {
            mfccs[i] += filtered_spectrum[j] * cos(M_PI * i * (j + 0.5) / NUM_FILTERS);
        }
        mfccs[i] *= ROOT_VALUE;
    }

}
